KK 1 Gram Jewellers website with your logo.

Upload BOTH files to the GitHub repository:
1. index.html
2. kk-logo.jpg

Then enable GitHub Pages: Settings -> Pages -> Deploy from a branch -> main -> / (root) -> Save.
